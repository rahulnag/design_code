import  React,{Component} from 'react';
import {View,TouchableOpacity,Text,StyleSheet,Dimensions,SafeAreaView } from 'react-native';
import * as firebase from 'firebase';
// import SafeAreaView from 'react-native-safe-area-view';
import { ScrollView } from 'react-native-gesture-handler';
import {Card, CardItem, Left, Right} from 'native-base';

var deviceWidth = Dimensions.get("window").width;
export default class SubService extends React.Component{

  static navigationOptions = {
    // set screen header name
    title: "My Screen",
  };


  constructor(props){
    super(props);
    this.state={
      data:[],
      // dataa:[
      //   {key: 'Android'},{key: 'iOS'}, {key: 'Java'},{key: 'Swift'},  
      //                   {key: 'Php'},{key: 'Hadoop'},{key: 'Sap'},  
      //                   {key: 'Python'},{key: 'Ajax'}, {key: 'C++'},  
      //                   {key: 'Ruby'},{key: 'Rails'},{key: '.Net'},  
      //                   {key: 'Perl'},{key: 'Sap'},{key: 'Python'},  
      //                   {key: 'Ajax'}, {key: 'C++'},{key: 'Ruby'},  
      //                   {key: 'Rails'},{key: '.Net'},{key: 'Perl'}  
      // ],
      isLoading:false,
      s:"",
      
  }

  }

  componentDidMount(){
    let service_name = this.props.navigation.getParam("service","")
    this.setState({
      s:service_name,
    })
    const ref = firebase.database().ref().child("design/"+service_name);
    //console.log(ref)
    ref.on("value", dataSnapshot=>{
      //console.log(Object.keys(dataSnapshot));
      //console.log(typeof(Object.keys(dataSnapshot.val())));//object
      this.setState({
        data:Object.keys(dataSnapshot.val()),
      })
      //console.log(this.state.data[1])
      // this.state.data.forEach((item,index)=>
      //   {
      //     this.state.data[index]="key:"+item;
      //   })
        
    })
  }


  render(){
    return(
      <ScrollView>
        <SafeAreaView style={styles.container}>
         { 
          this.state.data.map((item, key)=>(
           
          <TouchableOpacity 
            onPress={()=>{
              this.props.navigation.navigate("EachServiceDesignList",{
                  service:this.state.s+"/"+item,
              });
            }}>
            <Card style={styles.infoTextCard}>
              <Text key={key} > { item } </Text>
            </Card>
         </TouchableOpacity>
         )
         )}
         </SafeAreaView>
        </ScrollView>
    )
  }
}


const styles = StyleSheet.create({
  container: {
    flex: 1,
    flexDirection:"column",
    justifyContent:"center",
    alignItems:"stretch",
    backgroundColor: "#fff",
    margin:5,

  },
  infoTextCard: {
    // flex:1,
    justifyContent:"center",
    alignItems:"center",
    padding:5,
    borderBottomColor:'#34495e',
    borderRadius:10,
    shadowOpacity:50,
    height:deviceWidth/7,
  },
});
