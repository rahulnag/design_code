import React ,{Component} from'react';
import {StyleSheet, View, TouchableOpacity, Image, Text, SafeAreaView,Dimensions } from 'react-native';
// import SafeAreaView from 'react-native-safe-area-view';
// import {createAppContainer} from 'react-navigation';
// import { createStackNavigator } from 'react-navigation-stack';
// import * as firebase from "firebase";
import {Card, CardItem, Left, Right} from 'native-base';
import { ScrollView } from 'react-native-gesture-handler';
// import BottomNavigation from './BottomNavigation'
// import {Card} from 'natvie-base';

// TODO: as of now the service which i am providing is hard coded but has an entry as a root node in firebase,
// better if we will fetch those details here also and show them with suitable Image,
// and onCLick of it it will pass that service name to other screen


var deviceWidth = Dimensions.get("window").width;
export default class ServiceProvided extends React.Component{

    static navigationOptions = {
        // set screen header name
        title: "Home Screen",
      };
 
      //the view where in which i want to put flexWrap in that component dont put flex=1 like below
      //i want to put wrap in card views so in card we cant put flex=1.

    render(){
        return(
            <ScrollView>
        <SafeAreaView style={styles.main_container}>
            
            {/* <View style={styles.row_view}> */}
            <Card style={styles.cardContainer}>
                <TouchableOpacity 
                    style={styles.each_service}
                    onPress={()=>{
                    this.props.navigation.navigate("SubService",{
                        service:"interiorDesign",
                    });
                }}>
                    <Image 
                    style={{height:deviceWidth/8,width:deviceWidth/8}}
                    source={{uri:'https://cdn4.iconfinder.com/data/icons/realty-1/512/open_door-512.png'}}/>
                    <Text>Interior</Text>
                </TouchableOpacity>
            </Card>
                

            <Card 
            style={styles.cardContainer}>
                    <TouchableOpacity 
                    style={styles.each_service}
                    onPress={()=>this.props.navigation.navigate("EachServiceDesignList",{
                        service:"washroom",
                    })}>
                    <Image 
                    style={{height:deviceWidth/8,width:deviceWidth/8}}
                    source={{uri:'https://www.pinclipart.com/picdir/middle/356-3568459_clipart-bed-svg-bed-icon-vector-free-png.png'}}/>
                    <Text>Washroom</Text>
                </TouchableOpacity>
            </Card>     

            <Card 
            style={styles.cardContainer}>
                     <TouchableOpacity 
                    style={styles.each_service}
                    onPress={()=>this.props.navigation.navigate("EachServiceDesignList",{
                        service:"Kitchen",
                    })}>
                    <Image 
                    style={{height:deviceWidth/8,width:deviceWidth/8}}
                    source={{uri:'https://cdn4.iconfinder.com/data/icons/home-house-fixtures/372/funiture-02-001-512.png'}}/>
                    <Text>Kitchen</Text>
                </TouchableOpacity>
                
            </Card>   
            {/* </View> */}
            

            {/* <View style={styles.row_view}> */}
            <Card 
            style={styles.cardContainer}>
                     <TouchableOpacity 
                style={styles.each_service}
                onPress={()=>this.props.navigation.navigate("EachServiceDesignList",{
                    service:"KidsRoom",
                })}>
                    <Image 
                    style={{height:50,width:50}}
                    source={{uri:'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAASgAAACrCAMAAADiivHpAAAAe1BMVEX///8AAADu7u7t7e3x8fH39/f09PT4+Pj8/Pzi4uIzMzPU1NQpKSnFxcXQ0NA2NjZMTEy4uLhUVFQ7OzsiIiLn5+fd3d2ysrK+vr4vLy/Y2NiYmJglJSWrq6sLCwtKSkqioqKSkpISEhJpaWmCgoJZWVkbGxt4eHhBQUEGVjWwAAAL7ElEQVR4nO1d62KkKgxmENBpt9N2tzun7e52e249ff8nPCOgkyBXlapT8i91+hE+ERIhkRApNW2laqTSVEAhSuFKkT+jQilMKkwpQl1SCldwSmks2DXEtsExCCcg3EKmkkJUIaoQtRWirD37LERVca3jnlWw9Qq2XsHWLdg2omirVQxiU4jdERVpKg2YWqWZSmopXEhBCldapGJDyAmXhs0nm2ohvoLEV7YxYrupaIw4b2plu6m186YSz4M6hJtkahXCjn2UA61T2DoNTxMpDxPGXsbUQlQhqhC1EFGVlH6FbqVfoVvpW5fStS6lax0oCq5vHWIziC0scMQF18++ATibqQiuscAhU20970xtpNSsFaqUhkqlJkDhUiHqZwIojClFKKVpTWpOS+sZrlYIDRlgkyE2EwhO/Q9XzWqFMlGzthdWU08LvTQhbCrCDpmqb9xIL846+qs/v739/P1asWSHUypBz5yz6vX94e39B7OYerp29/Ph259V2NRUh1MTRROI8k4Tv3ZKHg4iTwhDbv7STdwb2KQShwd97dcaYj1P6/x118uBZSHq+tzCvTEE2OF87VUsT5R7PDPQi90XmoOo5gU0UWFT6RO4ds2yEJUyR1Ho6aNVVPwNLD0N/yFcKOCxxtjQmfgFW/iHIFPRtb+F19TU+F2verxbs85LIKuVphQOFaEUYSqC75CpxAlnwx7A9QqwjvwLW/iJ4Ai6TTsuPKb2nY3tucePGjon1ONHSeIZsvS3oF7Hh47wo9gbaqKCporf6BobwAX9KGSq4Ufhh8n9KEe5u3tk6RWLw07xzPGt6IlS2Ffo2t5r6rIhTDxRY0OYQlQh6lKISpnMg0HxgCh/FJs+mbuIkpbaiJpvMteLpHw93C2SStGLpH5z7FQEUJ6RpU8WOK103oYfrlOAdQQTJZCpT+jasx9uiG01tbOOoNHf3dTB6Hd75hV4UJFjfnLNLXBJQXFlcTgNoig09Qu61rrmdlNhZxcJih1EWbDHhzBpRK00KC5ERQbFn4Go0Ao9ZUQF5qgOGzkTAmLz0XNUot8TO0fRBvCKlQlE2bBrCBckCvbMIIpBOLzqpYwoT887orL6Udg5gbYacI6bauwUt7Zhono/SmJP9qN8mwv+MUKtj/Ioz1zzrv2ainHBzudTZGeU96I7ozTdGeXIWD1z5Y8p7DyeuaYhlqgpIUxD+Ovd09sDkLerr69dQzX9/he6aJOdlSjjN1mI+shY73Fnk7dDR9Teeh2LlSifbI4oRu5dfXnuRtQGiApM5jT2DacnKHZ37iVtRA2D4iBRE4JiY93hM0ptBsV1+9fmH3dnfjXy/2hEvyUWb+KJOtZz9o2gMUIGY6QdoYD4Cr04oQbxdj+KODrSyh2nLRz3/KQTZnM4fXLNAmPk/Kg4TipQMP46oujgUZ4t1vOyUMsQRsQQZXM4/URFTb4UTL7LBsXemfqiiUoMij8VUVNivRBRJ+wVE0XNtwfuyRyuosiZGMyQNJ0oLuGiiEqezOm0yRy/sB/vR9FIP4p5nSQJl9uPoqOCYoNW/8NkH6G2B9XpmYeJ4jk9c/ess7agOGZEbSGE2TZRR/nI0P2xlT1+cVeIAtK/VJenej54p5jOO5n7Z2pF1OjJPG6nOHoyh2uk+TLWkk8Um9NUm0lIzRFZ+iR/x/1ESbgqgii13VvjP9IGJk/hR+/YeEyNUHBnCRgjMX6U9zTBKIdzUlCsjqq5dmFm9aM0UXTwKG8i1lv3BuhCRK1jAzSFqMSgmF8/t7L/LuUZK+ogRXO+clRXjkoDykp2ijOOKJ1Tolui6hBup0A4nQuj4VS+iu5MC7AOomIn88EqGp7Mg6+tg6ldcPY1ico3mWNTu/sIT1bHHsdu4D+1O5amH+U+3T3qqLcEw0TpjCvdkOlHeUy1YXt7PqqSgTOj2eaZhxOcgmkT857hjMgTt9Hgn3XoPBugQ+wA3AoPu2Yk6lZvV6l/UhtT3VlIqXCXwl1KbWxXCYR9u1GiXm6vpNxKuXIqtwkK5mKH4G5f0LWsRFWWX0QRZZujFpb0OcpLQ9rcn7TqLSxTVz2c2kW6MZLBj1pYZt5c0ETR4Qid7JkvLNsJYRaWQlSkLE9U7NuDhSXnOXMSIqpCRLUaTDBZH1GewlipuTDdy2K1LuqXxUiRGncqNVCOYfM/To6mdX2+FOxfbM8D+VL0UzmcnlysrCHMwrKdWG9hKURFyscRNTUofro+tHItTwbskfIslQNS1PmBo1bUcQKlPKvfyf/HZBwQdtzZg9TTLIkjCio4X8r94k4Fl9oUHWlqOKl0VW4sivZNdEh7VgavggGc9eyBy9TkYz/dGNnm5gJHphqbC5sJii8yA7QQVYhajqiSfB0mKikoTi0QAeGcZbrTiApXdI4OiufMQKqNg2SzpjcpMbarGGyiNg6SzZtdNXyYJpTp9u4UO29qSpnu1OTruSqKl53iNcR6E4iin5qoykEUT1hJPgFRjZqMiYbgoi8mfFqh5XSpNe5SLER94NmDyHBraiWNx//e1TGBb1Jub3//98j7qonfr/or3+DPgPJgraSBf2Y5ezBfJQ1tK4XEQwXXT/GPP0dtFlDrGMl71Q25debrUTj+rETN7JmzG1dfjkzBZSMqokw3IsrjcI4gKjXWc5+f/sIzE7WpoJj46h6ISyYq8dEjL46enORfvjWiIl0ZTFQFW3cGxbWjI6281BI7T06xGRSHNwN8c5Q6GcbBRmmXXYQUed6qhnU4+ySkpt+E5dY6nN4UDyLhYkqOcNEakFBy5Jk7TOUWJdDz9kMagzEyc1CcNV/PJ2lBcTWgAb3j2XoG6Bii1hrCFKIKUYUoG1HZg2LqPTSliIqezM2gOEjU7GW6ExKcPF/xwO7BFxJ2DxqJHdN9a5nu5/NJhf1x/xNfm+crHlohzocp0jMPl+nOmSrbnbdXLcWW6aZgGllRme6SfF2ImjcoviyiUuYo5yo6siLZhxM1Pigel4Q0WAKFSVTcqifGr3oCmWp+nMKx0KWnjTWJ364a9bkTSg/tycHrGyXXSDlo7FZRPzuoK0NlQhGbjZXphkcTa5gEd4IDGXHwCj6auNC+nqYhlqgZNkAH00TZUi9EfWKisk/ms36IcMFvV7lrjEVW8QKFu4x35ldE9x1GlZGK8xImqkE/M9wD7jHVrnh6Tqw3lcKbOrpM98tXJXdSIpU7iwJ/h4nCCHhfDBWxMU2t1lSme2FZPtYrRM0cFC8s2ynTvbCMIcrtTHREeVZoOJnTlPKSC8vM31yooAMx7+bCwrKGoHj4oK42A9Rl6pqC4oVlO7HewlKIipS1fLuKXuBkDtdIs0z3nBlIays5MmffCBgjyd+uumw/qlQkK0ExluWJKkFxCYrDRIWmtE9YXtIo0+0fI73iqc2ilLU6nC5Tkz+77Z917CP0UiuSLRoUf329VwcI7pUo5TFO0f/0GFRe7+KJWmWs93TgQtvFnWcPGstxA6Q0UNFw+CiD4IenLRP13n59YtadYqepjL5/AFGJSUjRc9R3uEIPsUcUiPCkdpnnsNJzYbxlulEKEUxCworaUO3PW4GilVAxguIfjR/OpiDshg2tc5jKRPMDt47qcMZhe0wl3U3N4UdVQ7jJFcncL+yJ8amw7VQk2+nWLdjjyyL5TDWIWjzWW7TQls/UtR2fLkStiCjUmTURlWMyjygvCV+YTp7MP+LbVd0i6UyecichAYUYFcmEiIKbJ7XrtNobFcmIA86GHex5zjLdOb5d5TM107er8ocwDxkOu3rfCD1EEbWGWE/c/yHl/rGVmw8mit7IZjsb+IqJMsL9UOtzE6UU9R0+5sReQ5lub+vzBMULmUrRFxv7z3BKpfsMp1S4+pCn+lkNlEZ/4rMGil5KDDgG4NzYzRC7g6MQbrypbJypHfFz+FHJzgmCS/Oj8puaMSimqe7uzCFMTlMLUYWo5YlK3Ny6LKJCUURUmW5qXaE9Gc0IblimG5dwig14IsskpxaIcCdPuZOQuPufJsDlxJ4ON2+Z7vgCJaMdTu/3peYy1faoxD7KkSFMUlyQJ4TJYmohqhBViCpErZqo/wHO8MS1S08AjgAAAABJRU5ErkJggg=='}}/>
                    <Text>Kids Room</Text>
                </TouchableOpacity>
    </Card>
    <Card 
            style={styles.cardContainer}>
                     <TouchableOpacity 
                style={styles.each_service}
                onPress={()=>this.props.navigation.navigate("EachServiceDesignList",{
                    service:"StudyRoom",
                })} >
                    <Image 
                    style={{height:50,width:50}}
                    source={{uri:'https://cdn0.iconfinder.com/data/icons/education-full-black/128/education-fill-09-512.png'}}/>
                    <Text>Study Room</Text>
                </TouchableOpacity>
                </Card>
                <Card 
            style={styles.cardContainer}>
                    <TouchableOpacity 
                    style={styles.each_service} 
                    onPress={()=>this.props.navigation.navigate("EachServiceDesignList",{
                        service:"FitnessRoom",
                    })}>
                    <Image 
                    style={{height:50,width:50}}
                    source={{uri:'https://cdn1.iconfinder.com/data/icons/sports-32/64/sport-09-512.png'}}/>
                    <Text>Fitness Room</Text>
                </TouchableOpacity>
                </Card>
            {/* </View> */}

            {/* <View style={styles.row_view}> */}
            <Card 
            style={styles.cardContainer}>

                
                <TouchableOpacity 
                    style={styles.each_service}
                    onPress={()=>this.props.navigation.navigate("EachServiceDesignList",{
                        service:"RestRoom",
                    })}>
                    <Image 
                    style={{height:50,width:50}}
                    source={{uri:'https://cdn3.iconfinder.com/data/icons/airport-service-5/50/64-512.png'}}/>
                    <Text>Rest Room</Text>
                </TouchableOpacity>
                </Card>

                <Card 
            style={styles.cardContainer}>
                <TouchableOpacity 
                    style={styles.each_service} 
                    onPress={()=>this.props.navigation.navigate("EachServiceDesignList",{
                        service:"DiningRoom",
                    })}>
                    <Image 
                    style={{height:50,width:50}}
                    source={{uri:'https://cdn2.iconfinder.com/data/icons/home-24/54/dining_room_2-512.png'}}/>
                    <Text>Dining Room</Text>
                </TouchableOpacity>
                </Card>
                <Card 
            style={styles.cardContainer}>
                <TouchableOpacity 
                    style={styles.each_service}
                    onPress={()=>this.props.navigation.navigate("EachServiceDesignList",{
                    service:"Balconi",
                })}>
                    <Image 
                    style={{height:50,width:50}}
                    source={{uri:'https://cdn0.iconfinder.com/data/icons/real-estate-204/32/1_Balcony_Architecture_Building_Home-512.png'}}/>
                    <Text>Balconi</Text>
                </TouchableOpacity>
                </Card>
            {/* </View> */}


            {/* <View style={styles.row_view}> */}
            <Card 
            style={styles.cardContainer}>
                <TouchableOpacity 
                    style={styles.each_service}
                    onPress={()=>this.props.navigation.navigate("EachServiceDesignList",{
                        service:"StairsDesign",
                    })}>
                    <Image 
                    style={{height:50,width:50}}
                    source={{uri:'https://cdn0.iconfinder.com/data/icons/real-estate-vol-2-3-5/48/133-512.png'}}/>
                    <Text>Stairs Design</Text>
                </TouchableOpacity>
                </Card>

                <Card 
            style={styles.cardContainer}>
                <TouchableOpacity 
                    style={styles.each_service}
                    onPress={()=>this.props.navigation.navigate("EachServiceDesignList",{
                        service:"TerreceDeigns",
                    })}>
                    <Image 
                    style={{height:50,width:50}}
                    source={{uri:'https://cdn0.iconfinder.com/data/icons/housicon/512/terrace-512.png'}}/>
                    <Text>Terrece Deigns</Text>
                </TouchableOpacity>
                </Card>

                <Card 
            style={styles.cardContainer}>
                <TouchableOpacity 
                style={styles.each_service}
                onPress={()=>this.props.navigation.navigate("EachServiceDesignList",{
                    service:"DoorsGateDesigns",
                })}>
                    <Image 
                    style={{height:50,width:50}}
                    source={{uri:'https://cdn.iconscout.com/icon/premium/png-256-thumb/doorway-2-792718.png'}}/>
                    <Text>Doors/Gate Designs</Text>
                </TouchableOpacity>
               </Card> 
            {/* </View> */}



            {/* <View style={styles.row_view}> */}
            <Card 
            style={styles.cardContainer}>
                <TouchableOpacity 
                style={styles.each_service}
                onPress={()=>this.props.navigation.navigate("EachServiceDesignList",{
                    service:"WindowDesign",
                })}>
                    <Image 
                    style={{height:50,width:50}}
                    source={{uri:'https://icon-library.net/images/window-icon/window-icon-11.jpg'}}/>
                    <Text>Window Design</Text>
                </TouchableOpacity>
                </Card>
                <Card 
            style={styles.cardContainer}>
                <TouchableOpacity 
                style={styles.each_service} 
                onPress={()=>this.props.navigation.navigate("EachServiceDesignList",{
                    service:"YardDesign",
                })}>
                    <Image 
                    style={{height:50,width:50}}
                    source={{uri:'https://cdn0.iconfinder.com/data/icons/interior-and-decoration-1/64/41-512.png'}}/>
                    <Text>Yard Design</Text>
                </TouchableOpacity>
                </Card>

                <Card 
            style={styles.cardContainer}>
                <TouchableOpacity 
                style={styles.each_service}
                onPress={()=>this.props.navigation.navigate("EachServiceDesignList",{
                    service:"ItallianDesigns",
                })}>
                    <Image 
                    style={{height:50,width:50}}
                    source={{uri:'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRaOBoN3TvnS4fs8PiG9mNB-YCf93yW0NvSlCw9pS1ZpwL8IOJK'}}/>
                    <Text>Itallian Designs</Text>
                </TouchableOpacity>
                </Card>
            {/* </View> */}


            {/* <View style={styles.row_view}> */}
            <Card 
            style={styles.cardContainer}>
                <TouchableOpacity 
                style={styles.each_service}
                onPress={()=>this.props.navigation.navigate("EachServiceDesignList",{
                    service:"ChineeseDesign",
                })}>
                    <Image 
                    style={{height:50,width:50}}
                    source={{uri:'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQZreX2ak4WAY28_h7Z9In3TY_oT1qFebzU4ZUuPvswYph_YLKe'}}/>
                    <Text>Chineese Design</Text>
                </TouchableOpacity>
                </Card>
                <Card 
            style={styles.cardContainer}>
                <TouchableOpacity 
                style={styles.each_service}
                onPress={()=>this.props.navigation.navigate("EachServiceDesignList",{
                    service:"Aguarium",
                })}>
                    <Image 
                    style={{height:50,width:50}}
                    source={{uri:'https://icon-library.net/images/aquarium-icon/aquarium-icon-4.jpg'}}/>
                    <Text>Aguarium</Text>
                </TouchableOpacity>
                </Card>

                <Card 
            style={styles.cardContainer}>
                <TouchableOpacity 
                style={styles.each_service}
                onPress={()=>this.props.navigation.navigate("EachServiceDesignList",{
                    service:"MyOfficeDesign",
                })}>
                    <Image 
                    style={{height:50,width:50}}
                    source={{uri:'https://cdn0.iconfinder.com/data/icons/coworking-1/100/Coworking10-512.png'}}/>
                    <Text>My Office Design</Text>
                </TouchableOpacity>
                </Card>
            {/* </View> */}

            {/* <View style={styles.row_view}> */}
            <Card 
            style={styles.cardContainer}>

                
                <TouchableOpacity 
                style={styles.each_service}
                onPress={()=>this.props.navigation.navigate("EachServiceDesignList",{
                    service:"OtherDesign",
                })}>
                    <Image 
                    style={{height:50,width:50}}
                    source={{uri:'https://cdn4.iconfinder.com/data/icons/realty-1/512/open_door-512.png'}}/>
                    <Text>Other Design</Text>
                </TouchableOpacity>
                </Card>
                <Card 
            style={styles.cardContainer}>

                <TouchableOpacity 
                style={styles.each_service}
                onPress={()=>this.props.navigation.navigate("EachServiceDesignList",{
                    service:"TempleDesign",
                })}>
                    <Image 
                    style={{height:50,width:50}}
                    source={{uri:'https://cdn2.iconfinder.com/data/icons/buildings-52/24/Temple-512.png'}}/>
                    <Text>Temple Design</Text>
                </TouchableOpacity>
                </Card>
            <Card 
            style={styles.cardContainer}>
                <TouchableOpacity 
                style={styles.each_service}
                onPress={()=>this.props.navigation.navigate("EachServiceDesignList",{
                    service:"ShelvesDesign",
                })}>
                    <Image 
                    style={{height:50,width:50}}
                    source={{uri:'https://cdn2.iconfinder.com/data/icons/architecture-interior/24/architecture-interior-13-512.png'}}/>
                    <Text>Shelves Design</Text>
                </TouchableOpacity>
                </Card>

                <Card 
            style={styles.cardContainer}>
                <TouchableOpacity 
                style={styles.each_service}
                onPress={()=>this.props.navigation.navigate("EachServiceDesignList",{
                    service:"ShelvesDesign",
                })}>
                    <Image 
                    style={{height:50,width:50}}
                    source={{uri:'https://cdn2.iconfinder.com/data/icons/architecture-interior/24/architecture-interior-13-512.png'}}/>
                    <Text>Birthday Party</Text>
                </TouchableOpacity>
                </Card>
            {/* </View> */}
            
        </SafeAreaView>
        </ScrollView>
        )
    }
}


const styles=StyleSheet.create({
    main_container:{
        flex:1,
        flexDirection:'row',
        
        flexWrap:"wrap",
        // marginTop:20,
        margin:10,
        justifyContent:'space-between',
        // alignItems:'stretch',
        // backgroundColor:'#fab1a0',
        // alignItems: '',
        

    },

    cardContainer:{
        // flex:1,
        borderRadius:15,
        shadowOpacity:50, 
        alignItems:"center",
        height:deviceWidth/3,
        width:deviceWidth/4,
    },

    each_service:{
        flex:1,
        justifyContent:'center',
        alignItems:'center',
        flexDirection:"column",   
        // backgroundColor:"red",
        padding:5,
        borderRadius:15,
        // borderWidth: 1,
        borderColor: '#bdc3c7',
        borderWidth:1,
        height:deviceWidth/3,
        width:deviceWidth/4,
        // flexWrap:"wrap",
        resizeMode:'stretch',// recently added, if not workig then remove this one only.
    }
})
