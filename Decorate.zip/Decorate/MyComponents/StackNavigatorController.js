//Here we will put all those screen which we want to bring in stack 

import ServiceProvided from './ServiceProvided';
import SubService from './SubService';
import EachServiceDesignList from './EachServiceDesignList'
import ImageCollection  from './ImageCollection'
import MyCart  from './MyCart'
import {createAppContainer} from 'react-navigation';
import { createStackNavigator } from 'react-navigation-stack';


const ServiceProvided_stack = createStackNavigator(
    {ServiceProvided: {screen: ServiceProvided},
    SubService: {screen: SubService}, 
    EachServiceDesignList: {screen: EachServiceDesignList} , 
    ImageCollection:{screen: ImageCollection}, 
    // MyCart:{screen: MyCart}//commented on 12/15
  },
    {
      defaultNavigationOptions: {
        // title:"Service Provided",
        
        headerTintColor: "#fff",
        headerStyle: {
          backgroundColor: "#B83227"
        },
        headerTitleStyle: {
          color: "#fff"
        }
      },
      navigationOptions: {
        drawerLabel: 'Home!',
      },
    },
  );

  const StackNavigatorController = createAppContainer(ServiceProvided_stack);
  export default StackNavigatorController;