export var firebaseConfig = {
    apiKey: "AIzaSyDJaBc33e7xTr7_PLUANu7oUC9wRHNZ7YI",
    authDomain: "reactnativeproject-6470f.firebaseapp.com",
    databaseURL: "https://reactnativeproject-6470f.firebaseio.com",
    projectId: "reactnativeproject-6470f",
    storageBucket: "reactnativeproject-6470f.appspot.com",
    messagingSenderId: "727076909099",
    appId: "1:727076909099:web:d1c9327bf1404778db7a6e",
    measurementId: "G-TS6YCZPHWF"
  };
  // Initialize Firebase
//   firebase.initializeApp(firebaseConfig);
//   firebase.analytics();