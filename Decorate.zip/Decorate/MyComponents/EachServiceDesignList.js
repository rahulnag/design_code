import React,{Component} from 'react'
import {View, 
    StyleSheet,
    FlatList, 
    TouchableOpacity, 
    Image, 
    Button, 
    Text, 
    Dimensions,
    AsyncStorage,
    Alert,
    ActivityIndicator
} from 'react-native'
// import {createAppContainer} from 'react-navigation';
// import { createStackNavigator } from 'react-navigation-stack';
import * as firebase from 'firebase';
// import { Button,Text } from 'native-base';
import { Card,} from 'native-base';


var deviceWidth = Dimensions.get("window").width;
var ref;
cartList = new Set();
cart = [];
let temp = [];
// let keys = [];
const KeyCart= '@KeyCart';
export default class EachServiceDesignList extends Component{
    constructor(props)
    {
        super(props)
        
        this.state={
            data: [],
            isLoading: false,
            s: "",
            // temp: [],
            keys: [],

          
        }

        this.showValueLocally();
        
    }


    componentDidMount(){
        console.log("component did mount method");
        let service_name = this.props.navigation.getParam("service", "");
        
        // console.log(service_name)//interiorDesign/TV Shelves
        this.setState({
            s: service_name,
        })
        // console.log(service) this is correct
        //load firebase database and assign it to design variable
        ref = firebase.database().ref().child("design/"+service_name);
        // console.log(ref)//"https://reactnativeproject-6470f.firebaseio.com/design/interiorDesign/TV%20Shelves"
        ref.on("value", dataSnapshot=>{
        //console.log(Object.values(dataSnapshot.val()));
        // console.log((dataSnapshot.val()));
        // console.log(typeof(Object.values(dataSnapshot.val())));//object
        this.setState({
            data:Object.values(dataSnapshot.val()),
            // key:Object.keys(dataSnapshot.val()),
        })
        //console.log(this.state.data)
        // this.state.data.forEach((item,index)=>
        //   {
        //     this.state.data[index]="key:"+item;
        //   })
            
        })

        
    }

    
    showValueLocally= async()=>{
            console.log('collecting the cart value')
            this.setState({
                keys : await AsyncStorage.getAllKeys()
            })    
            if(this.state.keys.includes(KeyCart)){
                console.log("key is present so fetching in temp")
                // this.setState({temp : await AsyncStorage.getItem(KeyCart)})  
                temp = await AsyncStorage.getItem(KeyCart);
                this.temp.map(previouslytAddedItem => {
                    cartList.add(previouslytAddedItem);
                })
                // temp.forEach(previouslytAddedItem => cartList.add(previouslytAddedItem))
                console.log(temp);  
            }
            //in the very first time it triggers here
            else{
                console.log("key was not there so added")
                this.storeData("dummy_value");
                // this.setState({keys : await AsyncStorage.getAllKeys()})
                console.log(temp);
            }       
            // this.setState({
            //     isLoading: false,
            // })   
    }            


    storeData= async(a)=>{
        console.log("storing the data")
        console.log("value conming is.... "+ a)
        // this.state.temp.push();
        // this.state.temp.concat(a)
        // this.setState({
        //     temp: 
        // }
        // )

        cartList.add(a);
        cart= Array.from(cartList);

        console.log(cart)
        await AsyncStorage.setItem(KeyCart,JSON.stringify(cart));
        this.showValueLocally();
    }  

    render(){
        if (this.state.isLoading) {
            return (
              <View
                style={{
                  flex: 1,
                  alignContent: "center",
                  justifyContent: "center"
                }}
              >
                <ActivityIndicator size="large" color="#B83227" />
                <Text style={{ textAlign: "center" }}>
                  Loading please wait...
                </Text>
              </View>
            );
          }
          // else show contact details
        return(
            <FlatList 
                data={this.state.data}
                renderItem={({item}) =>
                {
                    return(
                        
                        <View style={styles.mainContainer}>
                        <Card style={{borderRadius:7,shadowOpacity:50}}>
                        {/* <Card> */}
                        <TouchableOpacity
                            onPress={()=>{
                                this.props.navigation.navigate("ImageCollection",{
                                    des : item.design, // always put 1 space after the : <<<<<<<<<    MUST   >>>>>>>>>>>>>
                                    service: this.state.s, // instead of this.state.s try once for service_name
                                    det: item.details,
                                    
                                })
                            }}>
                                
                        <View style={styles.details}>        
                            <View style={styles.avatarView}> 
                            {/* resizeMode:'contain' --> worked a bit */}
                            {/* resizeMode:'stretch' --> worked very fantastic */}
                                <Image
                                    style={{flex:1,height:deviceWidth/2,width:'100%',resizeMode:'stretch', borderRadius:7}}
                                    source={{uri: item.avatarImage}}       
                                />
                            
                             </View>

                            <View style={styles.detailsView}>

                                <Text style={{color:"#f53b57",fontSize: 18,}}>Name:</Text>
                                <Text style={{color:"#2c3e50",fontSize: 18,borderBottomColor: '#bdc3c7'}}>
                                    {item.name}
                                </Text>
                                <Text style={{borderBottomWidth: 0.5,marginBottom:10, borderColor:"#bdc3c7"}}></Text>

                                <Text style={{color:"#f53b57",fontSize: 18,marginTop:10}}>Price: </Text>
                                <Text style={{color:"#2c3e50",fontSize: 18}}>
                                    {item.pricing}
                                </Text>
                            </View> 
                        </View>         
                        </TouchableOpacity>  
            
                        <View style={styles.cartButton}>
                        <Button           
                            title="Add to cart"
                            // style={{backgroundColor:"red"}}
                            onPress={() =>{ 
                            // this.setState({
                            //     isLoading: true,
                            // })
                            this.showValueLocally();


     /*                       if(this.state.temp.length === 1){
                                // cartList.add(ref+"/"+item.design);
                                // cart= Array.from(cartList);
                                console.log(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>")
                                //AsyncStorage.setItem(KeyCart,JSON.stringify(cart))
                                this.storeData(ref+"/"+item.design)
                                // this.storeData(`"${ref+"/"+item.design}"`)
                                Alert.alert(`Added to Cart`)
                            }    
                            
                            else{
                                if(this.state.temp.includes(`"${ref+"/"+item.design}"`)){
                                            Alert.alert(`Already Available In Cart`)
                                }
                                
                                else
                                {
                                    // cartList.add(ref+"/"+item.design);
                                    // cart= Array.from(cartList);
                                    // temp.add(ref+"/"+item.design);
                                    console.log(",,,,,,,,,,,,,,,,")
                                    //AsyncStorage.setItem(KeyCart,JSON.stringify(cart))
                                    this.storeData(ref+"/"+item.design)
                                    Alert.alert(`Added to Cart.....`)
                                } 
                            }  
        */                   
       
        

                            if(cartList.has(ref+"/"+item.design)){
                                Alert.alert("item already exist in cart")
                            }

                            else{
                                this.storeData(ref+"/"+item.design)
                                Alert.alert(`Added to Cart.....`)
                            }
                        }  
                               
                            }
                        />
                        </View>  
                        </Card>                     
                        </View>   
                        
                               
                    )
                }}
                
                keyExtractor={(item, index) => index.toString()}
                
                >
            </FlatList>
        )
    }

}

const styles=StyleSheet.create({
    mainContainer:{
        flex:1,
        flexDirection:'column',
        // height:200,
        // justifyContent:"space-around",
        alignItems:"stretch", //try here stretch
        
        // padding:7,
        // borderWidth: 1,
        // borderRadius: 2,
        // borderColor: '#ddd',
        // shadowColor: '#000',
        // shadowOffset: { width:0, height:0},
        // shadowOpacity: 0.75,
        // shadowRadius: 5,
        // elevation: 4,
        margin:10
        
    },
   
    cartButton:{
        flex:1,
        // borderRadius:50,
        // borderWidth: 10,
        backgroundColor:"#dfe6e9",
        padding:10,
        alignItems:"center",

    },

    details:{
        flex:3,
        flexDirection:'row',
        justifyContent:"center",
        alignItems:"stretch",
        // backgroundColor:"blue"
    },

    detailsView:{
        flex:1, 
        // width:'50%', 
        textAlign:'right',
        padding:10,
        color: 'white',
        flexWrap:'wrap'

    },
    avatarView:{
        flex:2,
        // width: 200,
        // height: 100 ,
        // margin: 2,
        borderRadius : 7,
        // backgroundColor:"red",
        alignItems:"center",
        justifyContent:'flex-start',
        flexWrap:'wrap'
        // padding: 10, //working fine
    },
    
});