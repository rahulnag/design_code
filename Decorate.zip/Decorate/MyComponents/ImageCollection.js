import React,{Component} from 'react'
import {View,Text, Card, StyleSheet,SafeAreaView ,Dimensions,Image,TouchableHighlight,} from 'react-native'
import * as firebase from 'firebase';
import ImageSlider from 'react-native-image-slider';
import { ScrollView } from 'react-native-gesture-handler';


var deviceWidth = Dimensions.get("window").width;
var details;
export default class ImageCollection extends Component{
  
    constructor(props)
    {
        super(props)
        
        // console.log("in ImageCollection screen")
        this.state={
            data:[],
            
        }
    }

    componentWillMount(){
        
        let design= this.props.navigation.getParam("des","");
        let forService=this.props.navigation.getParam("service","");
        details=this.props.navigation.getParam("det","NA");

        // console.log("in ImageCollection screen"+design+"........."+forService)
        let ref=firebase.database().ref().child("design/"+forService+"/"+design+"/"+"imageCollection")
        //console.log(ref)
        ref.on("value",datasnapshot =>
        {
            //its better to use the array of all the image of a particular design, as each desing is having its own number of image.
           // console.log(Object.values(datasnapshot.val()))
            this.setState({
                data: Object.values(datasnapshot.val()),
            })

            
        })
        // console.log(data)
    }

    render(){
      // console.log(details)
      const images=this.state.data;

      return(
         
      <SafeAreaView style={styles.container}>
      {/* <View style={styles.content1}>
        <Text style={styles.contentText}>Content 1</Text>
      </View> */}
        <View style={styles.imageSliderView}>
        <ImageSlider
                loopBothSides
                autoPlayWithInterval={3000}
                images={images}
                customSlide={({ index, item, style, width }) => (
                  // It's important to put style here because it's got offset inside
                  <View key={index} style={[style, styles.customSlide]}>
                    <Image source={{ uri: item }} style={styles.customImage} />
                  </View>
                )}
                customButtons={(position, move) => (
                  <View style={styles.buttons}>
                    {images.map((image, index) => {
                      return (
                        <TouchableHighlight
                          key={index}
                          underlayColor="#e74c3c"
                          onPress={() => move(index)}
                          style={styles.button}
                        >
                          <Text style={position === index && styles.buttonSelected}>
                            {index + 1}
                          </Text>
                        </TouchableHighlight>
                      );
                    })}
                    </View>
        )}
      />
      </View>

      
      <View style={styles.content}>
      <ScrollView>           
          <Text style={styles.contentText}>{details}</Text>
          </ScrollView>
      </View>
      
    </SafeAreaView>
      )
  }

    
}


const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#ecf0f1',
    flexDirection:'column',
  },

  imageSliderView: {
    flex:1.5,
    // borderRadius: 50,
    backgroundColor:"#ecf0f1",
  },

  content: {
    flex: 1,
    // width: deviceWidth,
    // height: deviceWidth/2,
    // marginTop:deviceWidth/5,
    margin: 2,
    backgroundColor: '#a29bfe',
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius:10,
    // borderWidth: 1,
    borderColor: '#bdc3c7',
    borderWidth:1,
    // flexWrap:'wrap'
  },

  customSlide: {
    flex:1,
    backgroundColor: '#ecf0f1',
    alignItems: 'center',
    justifyContent: 'center',
    //TODO: remove margin
    // margin: 10, 
    
  },
  
customImage: {
    flex:1,
    width:deviceWidth,
    height:deviceWidth/5,
    // margin:10,
    resizeMode:"stretch",
  },
  

buttons: {
      zIndex: 1,
      height: 15,
      marginTop: -25,
      marginBottom: 10,
      justifyContent: 'center',
      alignItems: 'center',
      flexDirection: 'row',
    },
button: {
      margin: 3,
      width: 15,
      height: 15,
      opacity: 0.9,
      alignItems: 'center',
      justifyContent: 'center',
    },
    
buttonSelected: {
      opacity: 1,
      color: 'red',
    },



contentText: { color: '#1e272e' },
        
});