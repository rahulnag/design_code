//in this screen we will create the screen for the Drawer naviator and
// we will put all the screen which we want to show them in the Drawer.
import {createAppContainer} from 'react-navigation';
import {createDrawerNavigator} from 'react-navigation-drawer'
import StackNavigatorController from './StackNavigatorController'
import LogoutScreen from './LogoutScreen';
import MyCart from './MyCart';

const MyDrawer = createDrawerNavigator({
        // Home: {screen: ServiceProvided},
        ServiceProvided:{screen: StackNavigatorController},
        MyCart: {screen: MyCart},
        LogoutScreen: {screen: LogoutScreen}
  },
  // {
  //   defaultNavigationOption: {
  //     headerTintColor: "#fff",
  //     headerStyle: {
  //       backgroundColor: "#B83227"
  //     },
  //     headerTitleStyle: {
  //       color: "#fff"
  //     }
  //   }
  // } 
  );
  
  const DrawerNavigatorController = createAppContainer(MyDrawer);
  export default DrawerNavigatorController;