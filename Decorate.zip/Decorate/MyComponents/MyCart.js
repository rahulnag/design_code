import React,{Component} from 'react'
import {View,Text, Card, StyleSheet,FlatList, TouchableOpacity, SafeAreaView, AsyncStorage, Button , Alert} from 'react-native'
// import { Button } from 'native-base';


const KeyCart='@KeyCart';
export default class MyCart extends React.Component{
    constructor(props)
    {
        super(props)
        console.log("in my Cart screen")
        this.showValueLocally();
    }

    componentDidMount(){
        // console.log("in my Cart screen")
        cartItemLink= this.props.navigation.getParam("cartItemLink")
        
        
    }

    showValueLocally= async()=>{
 
        var item= await AsyncStorage.getItem(KeyCart);
        console.log(item);
     
      }

      clearCart= async()=>{
            await AsyncStorage.removeItem(KeyCart);
            this.showValueLocally();
            Alert.alert('Opps!!, Cart Cleared');
            
      }



    render(){
        return(
            <View>
                <Button
                    title="clear cart"
                //     onPress= {
                //         this.clearCart;                   
                // } 
                onPress= {() => {
                    // then we have to call as 
                    this.clearCart()
                }}
                style={{flex:1,}}   
                />
            </View>
        )
    }
}